package pkg1;

public class A {
	void ma1(int str1) {
	}
	void ma2(String str1, int i1) {
	}
}
